import PySimpleGUI as sg
import random
analo = 0
inivelo = 5
velo = 15
ven = False
reco = False
perdeu = False
ini = False
fimblz = False
pausa = False
inimigoa = False
inimigo = True
lista = ["images/cobrinha.png","images/cobrinha2.png"]
lista2 = ["images/cobrinha_esquerda.png","images/cobrinha2_esquerda.png"]
menu2 = [["controles",[["ajuda"]]]]
modo = [["configurações",["recomeçar","pausar","modo",["fácil","normal","difícil"]]],['controles',['ajuda']]]
modo2 = [["configurações",[["recomeçar","play","modo",[["fácil","normal","difícil"]] ]] ]]
vvv = 0
okay = False
sg.theme("green")
ponto = 0
aa  = random.randint(1,35)
bb = random.randint(12,42)
a  = random.randint(0,35)
b = random.randint(12,50)
a = a * 10
b = b * 10
aa = aa * 10
bb = bb * 10
var1 = 140
var2 = 250
layout = [
    [sg.Menu(modo,key = "menu")],
    [sg.Text("Pontos do jogador: 0 ",size=(20,1),font = ("Helvetica",15),key = "_PONTOS_")],
    [sg.Button("Recomeçar",size=(10,1),font = ("Helvetica",15),key = "recomeçar")],
    [
        sg.Graph(
            canvas_size=(700, 520),
            graph_bottom_left=(0, 0),
            graph_top_right=(500, 500),
            change_submits=True,
            drag_submits= True,
            key="graph"
         
        )
    ],
    [sg.Button("",visible = False,key = "frame" )]
]
window = sg.Window("Snake",return_keyboard_events=True,layout=layout, location = (0,0)).Finalize()
graph = window.Element("graph")

imagem = graph.DrawImage(filename="images/cobrinha2.png", location=(140,250))
maca = graph.DrawImage(filename="images/maca2.png", location=(a,b))
while True:
    event, values = window.Read(timeout=100)
    if event == 'ajuda':
        sg.Popup("As teclas  de movimentação são:\n (w) para cima.\n (s) para baixo.\n (d) para direita.\n (a) para esquerda.\n    (w)   \n(a) (s) (d)",location = (100,200),title = "controles")
    if event == "fácil":
        ana = 10
        velo = 10
        inivelo = 2
    if event == "normal":
        ana = 60
        inivelo = 5
        velo = 15
    if event == "difícil":
        velo = 10
        inivelo = 5
    if event == "pausar":
        pausa = True
        window.FindElement("menu").Update(modo2)
        pausado = graph.DrawImage(filename="images/pausado.png", location=(160, 350))
        window.FindElement("_PONTOS_").Update(visible = False)
        window.FindElement("frame").Update(visible = False)
        window.FindElement("recomeçar").Update(visible = False)
    if event == "play":
        graph.DeleteFigure(pausado)
        pausa = False
        window.FindElement("menu").Update(modo)
        window.FindElement("_PONTOS_").Update(visible = True)
        window.FindElement("recomeçar").Update(visible = True)
    vvv += 1
    if vvv % 2 == 0:
        cv = 0
    elif vvv % 2 != 0:
        cv = 1
    v1 = var1
    v2 = var2
    for i in range(0,1):
        if a - var1 <= 40 and b - var2  <= 40 and b - var2  >= -40 and a - var1 >= -40 :
            graph.DeleteFigure(maca)
            okay = True     
    if okay == True:
        graph.DeleteFigure(maca)
        a = random.randint(0,30)
        b = random.randint(12,50)
        ponto += 1
        window.FindElement("_PONTOS_").Update(f"Pontos do jogador: {ponto} ")
        a = a * 10
        b = b * 10
        maca = graph.DrawImage(filename="images/maca2.png", location=(a,b))
        okay = False       
    if aa == a and bb == b:
            graph.DeleteFigure(maca)
            okay = True     
    if okay == True:
        graph.DeleteFigure(maca)
        a = random.randint(0,30)
        b = random.randint(12,50)
        ponto -= 1
        window.FindElement("_PONTOS_").Update(f"Pontos do jogador: {ponto} ")
        a = a * 10
        b = b * 10
        maca = graph.DrawImage(filename="images/maca2.png", location=(a,b))
        okay = False
    if ponto == 10 and ven == False:
         ven = True
         venceu = graph.DrawImage(filename="images/venceu.png", location=(150, 400))
         sg.Popup("vitória! parabéns!", location = (100,500),title = ":-)")
    if ponto == -1 and fimblz == False:
            fimblz = True
            fim = graph.DrawImage(filename="images/gameover.png", location=(150, 400))
            sg.Popup("derrota! tente mais uma vez!",location = (100,500),title = ":-(")
    if inimigo == True and ponto == 5 and pausa == False:
        inimigo = False
        inimigoa = True
        inimigo = graph.DrawImage(filename="images/cobrinha_red.png", location=(aa, bb))
    if inimigoa == True and pausa == False:  
        if  aa < a:
              ini = True
              graph.DeleteFigure(inimigo)
              aa = aa + inivelo
              inimigo = graph.DrawImage(filename="images/cobrinha_red.png", location=(aa, bb))
        if bb > b:
              ini = True
              graph.DeleteFigure(inimigo)
              bb = bb - inivelo
              inimigo = graph.DrawImage(filename="images/cobrinha_red.png", location=(aa, bb))
        if  aa > a:
                    ini = True
                    graph.DeleteFigure(inimigo)
                    aa = aa - inivelo
                    inimigo = graph.DrawImage(filename="images/cobrinha_red.png", location=(aa, bb))
        if bb < b:
                    ini = True
                    graph.DeleteFigure(inimigo)
                    bb = bb + inivelo
                    inimigo = graph.DrawImage(filename="images/cobrinha_red.png", location=(aa, bb))
    if event == "esquerda" or event == 'd':
        graph.DeleteFigure(imagem)
        var1 = var1 + velo            
        imagem = graph.DrawImage(filename=lista[cv], location=(var1, var2))
    if event == "cima" or event == 'w':
        var2 = var2 + velo
        graph.DeleteFigure(imagem)
        imagem = graph.DrawImage(filename=lista[cv], location=(var1, var2))
    if event == "direita" or event == "a":
        var1 = var1 - velo
        graph.DeleteFigure(imagem)
        imagem = graph.DrawImage(filename=lista2[cv], location=(var1, var2))
    if event == "baixo" or event == "s":
        var2 = var2 - velo
        graph.DeleteFigure(imagem)
        imagem = graph.DrawImage(filename=lista[cv], location=(var1, var2))  
    if event == "recomeçar":
        graph.DeleteFigure(imagem)
        graph.DeleteFigure(maca)
        if ponto >= 5 or ini == True:
            graph.DeleteFigure(inimigo)
        window.FindElement("_PONTOS_").Update(visible = True)
        window.FindElement("recomeçar").Update(visible = True)
        if pausa == True:
            graph.DeleteFigure(pausado)
        if ven == True:
            graph.DeleteFigure(venceu)
            ven = False
        pausa = False
        inimigoa = False
        inimigo = True
        ponto = 0
        ven = False
        if fimblz == True:
            graph.DeleteFigure(fim)          
            fimblz = False
        aa  = random.randint(1,35)
        bb = random.randint(12,42)
        a  = random.randint(0,35)
        b = random.randint(12,50)
        window.FindElement("_PONTOS_").Update(f"Pontos do jogador: {ponto}")
        a = a * 10
        b = b * 10
        aa = aa * 10
        bb = bb * 10
        var1 = 140
        var2 = 250
        imagem = graph.DrawImage(filename="images/cobrinha2.png", location=(140,230))
        maca = graph.DrawImage(filename="images/maca2.png", location=(a,b))
    if event is None:
        break
